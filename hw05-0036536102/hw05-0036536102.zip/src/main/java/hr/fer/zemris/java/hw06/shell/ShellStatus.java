package hr.fer.zemris.java.hw06.shell;

/**
 * Enum koji predstavlja moguce statuse shella.
 * @author Petra
 *
 */
public enum ShellStatus {
	CONTINUE,
	TERMINATE

}
